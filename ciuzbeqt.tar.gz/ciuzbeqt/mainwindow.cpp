#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTimer>
#include <QTime>
#include <QPixmap>
#include <time.h>
#include <stdlib.h>
bool habibikiller = false;
bool hiding = false;

int randomnumber = 0;
int points = 0;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->pushButton_3->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void delay()
{
    QTime dieTime= QTime::currentTime().addSecs(1);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

void delay2()
{
    QTime dieTime= QTime::currentTime().addMSecs(400);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}
void MainWindow::on_pushButton_clicked()
{
    QPixmap coding (":/pictures/cod.png");
    QPixmap normal (":/pictures/0.png");
    QPixmap flies (":/pictures/1.png");
    QPixmap hamwatch (":/pictures/2.png");
    QPixmap BASTRARD (":/pictures/3.png");
    QPixmap himding (":/pictures/h.png");
    QPixmap dead (":/pictures/dead.png");
    if(habibikiller == false){
    srand (time(NULL));
    points = points + 1;
    ui->label_3->setText( QString::number( points ) );
    ui->label->setPixmap(coding);
    ui->pushButton->setVisible(false);
    ui->pushButton_2->setVisible(false);
    delay();
    ui->pushButton->setVisible(true);
    ui->pushButton_2->setVisible(true);
    randomnumber = rand() % 4 + 1;
    if(randomnumber == 1){
      ui->label->setPixmap(normal);
    }else if(randomnumber == 2) {
      ui->label->setPixmap(flies);
    }else if(randomnumber == 3) {
      ui->label->setPixmap(hamwatch);
    }else if(randomnumber == 4) {
      habibikiller = true;
      ui->label->setPixmap(BASTRARD);
      }

    delay2();
    ui->label->setPixmap(normal);
    }else{
        ui->pushButton->setVisible(false);
        ui->pushButton_2->setVisible(false);
        ui->pushButton_3->setVisible(true);
      ui->label->setPixmap(dead);
    }
}


void MainWindow::on_pushButton_2_clicked()
{
    QPixmap coding (":/pictures/cod.png");
    QPixmap normal (":/pictures/0.png");
    QPixmap flies (":/pictures/1.png");
    QPixmap hamwatch (":/pictures/2.png");
    QPixmap BASTRARD (":/pictures/3.png");
    QPixmap himding (":/pictures/h.png");
    QPixmap dead (":/pictures/dead.png");

    srand (time(NULL));
    ui->label->setPixmap(himding);
    hiding = true;
    if(habibikiller == true){
    points = points + 1;
    }else if(points > 0){
    points = points - 1;
    }
    ui->label_3->setText( QString::number( points ) );
    ui->pushButton->setVisible(false);
    ui->pushButton_2->setVisible(false);
    delay();
    hiding = false;
    ui->pushButton->setVisible(true);
    ui->pushButton_2->setVisible(true);
    habibikiller = false;
    randomnumber = rand() % 4 + 1;
    if(randomnumber == 1){
      ui->label->setPixmap(normal);
    }else if(randomnumber == 2) {
      ui->label->setPixmap(flies);
    }else if(randomnumber == 3) {
      ui->label->setPixmap(hamwatch);
    }else if(randomnumber == 4) {
      habibikiller = true;
      ui->label->setPixmap(BASTRARD);
  }

    delay2();
    ui->label->setPixmap(normal);
}

void MainWindow::on_pushButton_3_clicked()
{
  close();
}

void MainWindow::on_pushButton_4_clicked()
{
    ui->pushButton_4->setVisible(false);
    ui->label_4->setVisible(false);
}
